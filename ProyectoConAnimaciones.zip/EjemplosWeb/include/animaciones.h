/*

#include <winbgim.h>
#include <stdio.h>



void presionado(int op);
void boton(int x,int y,int x2,int y2,int c1,int c2);
void clean();
int cordx,cordy;
int c,r,r2,x,y,x2,y2,R,G,B;
char op;

int main()
{//inico del programa
    initwindow(1024,776);


    setcolor(15);
    rectangle(8,7,791,651);
    setcolor(0);
    rectangle(9,8,790,650);
    setfillstyle(1,COLOR(54,92,248));//color azul de la ventana
    bar(10,9,790,650);//ventana
    setfillstyle(1,COLOR(221,215,210));//color arena de de la segunda
    bar(13,38,787,647);//segunda ventana (dentro de la otra)
    setcolor(0);//color margen
    rectangle(13,38,787,647);//margen
    setfillstyle(1,COLOR(0,0,0));//color fondo
    bar(20,100,780,643);//fondo en donde apareceran las figuras

    setbkcolor(COLOR(54,92,248));//fondo de letra
    settextstyle(10,0,1);//tipo de letra
    setcolor(15);//color de letra
    outtextxy(19,12,"Seleciona una opci�n");//titulo

    setfillstyle(1,COLOR(223,21,10));//fondo rojo boton cerrar
    bar(760,12,785,35);//fondo boton cerrar
    boton(760,12,785,35,15,0);//boton cerrar
    setcolor(15);//color cruz
    line(763,33,782,15);//cruz
    line(764,33,783,15);//cruz
    line(763,15,782,33);//cruz
    line(764,15,783,33);//cruz
    boton(730,12,755,35,15,0);//boton maximizar
    setcolor(15);//color guion
    rectangle(733,15,750,32);//cuadro
    rectangle(733,14,750,32);//cuadro
    boton(700,12,725,35,15,0);//boton minimizar
    setcolor(15);//color guion
    line(703,30,715,30);//guion
    line(703,31,715,31);//guion

    boton(20,42,113,95,15,0);//primer boton
    setbkcolor(COLOR(221,215,210));
    outtextxy(35,60,"Pixel");///*****nombre boton
    rectangle(37,80,44,81);//indica la letra P
    boton(120,42,218,95,15,0);//segundo boton
    outtextxy(128,60,"Circulo");///*****nombre boton
    rectangle(133,80,141,81);//indica letra C
    boton(225,42,318,95,15,0);//tercer boton
    outtextxy(253,60,"Bar");///*****nombre boton
    rectangle(255,80,265,81);//indica letra B
    boton(325,42,418,95,15,0);//cuarto boton
    outtextxy(336,60,"Lineas");///****nombre boton
    rectangle(338,80,347,81);//indica la letra N
    boton(425,42,540,95,15,0);//quinto boton
    outtextxy(436,60,"Botones");///****nombre boton
    rectangle(468,80,474,81);//indica letra T
    boton(550,42,670,95,15,0);//sexto boton
    outtextxy(570,60,"Elipses");///****nombre boton
    rectangle(572,80,581,81);
    boton(680,42,780,95,15,0);//septimo boton
    outtextxy(705,60,"Salir");
    rectangle(707,80,716,81);
    do
    {
	do
	{
	getmouseclick(WM_LBUTTONDOWN,cordx,cordy);

	if(cordx>20&&cordy>42&&cordx<113&&cordy<95)//en caso de presionar el boton PIXEL
	presionado('p');
	if(cordx>120&&cordy>42&&cordx<218&&cordy<95)//en caso de presionar el boton CIRCULO
	presionado('c');
	if(cordx>225&&cordy>42&&cordx<318&&cordy<95)//en caso de presionar el boton BAR
	presionado('b');
	if(cordx>325&&cordy>42&&cordx<418&&cordy<95)//si presionan el boton LINEAS
	presionado('l');
	if(cordx>425&&cordy>42&&cordx<540&&cordy<95) //si presionan el boton BOTONES
	presionado('t');
	if(cordx>550&&cordy>42&&cordx<670&&cordy<95)//al pulsar el boton ELIPSE
	presionado('e');
	if(cordx>680&&cordy>42&&cordx<780&cordy<95)//Entra el case al pulsar S o s
	presionado('s');
	}while(!kbhit());//espera teclado
	op=getch();//si es una opcion entra
	switch(op)//inicio switch
	{
		case 'p':
		case 'P':
			presionado('p');
		break;
        case 'c':
		case 'C':
			presionado('c');
        break;
        case 'b':
		case 'B':
			presionado('b');
        break;
        case 'l':
		case 'L':
			presionado('l');
        break;
        case 't':
		case 'T':
			presionado('t');
        break;
        case 'e':
		case 'E':
            presionado('e');
        break;
        case 's':
		case 'S':
			presionado('s');
        break;
	}//termina switch
	}while(1);	//ciclo infinito

    closegraph();
	return 0;
}//fin del programa



void presionado(int op) //funcion presionado con un switch
{


    switch(op)
    {//inico switch
              case 'p'://en caso de presionar P o p se activara PIXEL
              case 'P':

                    for(int i=0;i<1;i++)//i es el contador de veces que tendra que correr el ciclo
                    {
                    boton(20,42,113,95,15,0);//animacion del boton PIXEL
                    delay(100);
                    boton(20,42,113,95,0,15);
                    delay(100);
                    boton(20,42,113,95,15,0);
                    delay(100);
                    }
                    for(int cont=0;cont<100000;cont++)//cont es el contador de veces que correra el ciclo (hasta 100000)
					{
                    x=(rand()%760)+20;
                    y=(rand()%543)+100;
                    R=(rand()%250)+15;
                    G=(rand()%255);
                    B=(rand()%230)+300;
                    c=COLOR(R,G,B);
                    r=(rand()%15);
                    setcolor(c);
                    putpixel(x,y,COLOR(R,G,B));//pixeles
                    }
                    clean();
                    break;
              case 'c'://en caso de presionar C o c se activara CIRCULO
              case 'C':
                   for(int i=0;i<1;i++)//i es el contador de veces que correra el ciclo
                    {
                    boton(120,42,218,95,15,0);//animacion del boton CIRCULO
                    delay(100);
                    boton(120,42,218,95,0,15);
                    delay(100);
                    boton(120,42,218,95,15,0);
                    delay(100);
                    }
                    for(int cont=0;cont<50000;cont++)//cont cuenta el numero de veces que corre el ciclo y para hasta contar 50000
                    {
                    x=(rand()%743)+29;
                    y=(rand()%525)+110;
                    R=(rand()%250)+15;
                    G=(rand()%255);
                    B=(rand()%230)+300;
                    c=COLOR(R,G,B);
                    r=(rand()%10);
                    setcolor(c);
                    circle(x,y,r);//circulos aleatorios
                    }
                    clean();
                    break;
              case 'b'://si presionan B o b se activa BAR
              case 'B':
                   for(int i=0;i<1;i++)//i cuenta el numero de veces que se anima el boton BAR
                   {
                    boton(225,42,318,95,15,0);//animacion boton BAR
                    delay(100);
                    boton(225,42,318,95,0,15);
                    delay(100);
                    boton(225,42,318,95,15,0);
                    delay(100);
                    }
                    for(int cont=0;cont<10000;cont++)//cont hace que el ciclo pare al llegar 10000
                    {
                    x=(rand()%760)+20;//rango en pantalla
                    y=(rand()%543)+100;//rango en pantalla
                    x2=(rand()%760)+20;
                    y2=(rand()%543)+100;
                    R=(rand()%250)+15;
                    G=(rand()%255);
                    B=(rand()%230)+300;
                    c=COLOR(R,G,B);
                    setfillstyle(1,c);
                    bar(x,y,x2,y2);// bar de tama�o y ubicacion aleatoria
                    }
                    clean();
                    break;
              case 'l'://si presionan L o l se activa LINEAS
              case 'L':
                   for(int i=0;i<1;i++)//i cuenta el numero de veces que se anima el boton LINEAS
                    {
                    boton(325,42,418,95,15,0);//animacion boton LINEAS
                    delay(100);
                    boton(325,42,418,95,0,15);
                    delay(100);
                    boton(325,42,418,95,15,0);
                    delay(100);
                    }
                    for(int cont=0;cont<100000;cont++)//hasta contar 100000 se detiene el ciclo
                    {
                    x=(rand()%740)+20;
                    y=(rand()%542)+101;
                    x2=(rand()%760)+20;
                    y2=(rand()%542)+101;
                    R=(rand()%250)+5;
                    G=(rand()%255);
                    B=(rand()%230)+25;
                    c=COLOR(R,G,B);
                    r=(rand()%10);//tama�o del circulo
                    setcolor(c);
                    setcolor(c);
                    line(x,y,x2,y2);//lineas de tama�o y ubicacion aleatoria
                    }
                    clean();
                    break;

              case 't'://si teclean T o t se activa el case BOTONES
              case 'T':
                   for(int i=0;i<1;i++)//ciclo para activar el boton
                    {
                    boton(425,42,540,95,15,0);//animacion del boton BOTONES
                    delay(100);
                    boton(425,42,540,95,0,15);
                    delay(100);
                    boton(425,42,540,95,15,0);
                    delay(100);
                    }
                    //for(int cont=0;cont<100;cont++)//para al llegar a 100 BOTONES
                    do{
                    x=(rand()%760)+20;
                    y=(rand()%543)+100;
                    x2=(rand()%760)+20;
                    y2=(rand()%543)+100;
                    R=(rand()%250)+15;
                    G=(rand()%255);
                    B=(rand()%230)+300;
                    c=COLOR(R,G,B);
                    for(int cont2=0;cont2<1;cont2++)//ejecuta una vez la animacion de los BOTONES
                    {
                    boton(x,y,x2,y2,c,15);//llamada a funcion BOTON
                    delay(100);//tiempo de animacion
                    boton(x,y,x2,y2,15,c);
                    delay(100);//tiempo de animacion
                    boton(x,y,x2,y2,c,15);
                    delay(100);//tiempo de animacion

                    boton(x-1,y+1,x2,y2,c,15);//llamada a funcion BOTON
                    delay(100);//tiempo de animacion
                    boton(x-1,y+1,x2,y2,15,c);
                    delay(100);//tiempo de animacion
                    boton(x-1,y+1,x2,y2,c,15);
                    delay(100);//tiempo de animacion
                    }
                    }while(!kbhit());
                    clean();
                    break;
              case 'e'://al pulsar E o e entra en el case
              case 'E':
                    for(int i=0;i<1;i++)//i se detiene al animarse una vez el boton ELIPSES
                    {
                    boton(550,42,670,95,15,0);//animacion del boton ELIPSES
                    delay(100);
                    boton(550,42,670,95,0,15);
                    delay(100);
                    boton(550,42,670,95,15,0);
                    delay(100);
                    }
                    for(int cont=0;cont<50000;cont++)//al ejecutarse 1000 elipses se detiene el ciclo
                    {
                    x=(rand()%715)+45;
                    y=(rand()%513)+115;
                    R=(rand()%250)+15;
                    G=(rand()%255);
                    B=(rand()%230)+300;
                    r=(rand()%25);
                    r2=(rand()%15);
                    c=COLOR(R,G,B);
                    setcolor(c);//color aleatorio de los elipses
                    ellipse(x,y,0,360,r,r2);//ubicacion aleatoria de los elipses

                    }
                    clean();
                    break;
              case 's'://Entra el case al pulsar S o s
              case 'S':
                   for(int i=0;i<1;i++)
                   {
                   boton(680,42,780,95,15,0);//se anima una vez el boton SALIR
                   delay(100);
                   boton(680,42,780,95,0,15);
                   delay(100);
                   boton(680,42,780,95,15,0);
                   delay(100);
                   }
                   for(int ca=0;ca<15;ca++)
                   {
                   R=(rand()%250)+15;
                   G=(rand()%255);
                   B=(rand()%230)+300;
                   c=COLOR(R,G,B);
                   setcolor(c);
                   settextstyle(9,0,6);
                   setbkcolor(COLOR(0,0,0));
                   outtextxy(220,300,"Hasta pronto!!");//texto de despedida
                   delay(100);//duracion del mensaje
                   }
                   for(int cont=0;cont<1;cont++)//se anima el boton CERRAR
                   {
                   boton(760,12,785,35,15,0);//animacion boton CERRAR
                   delay(100);
                   boton(760,12,785,35,0,15);
                   delay(100);
                   boton(760,12,785,35,15,0);
                   delay(100);
                   }
                   exit(0);//sale del programa
                   break;
              default:
                      for(int i=0;i<15;i++)
                      {
                      R=(rand()%250)+15;
                      G=(rand()%255);
                      B=(rand()%230)+300;
                      c=COLOR(R,G,B);
                      setcolor(c);
                      settextstyle(4,0,3);
                      setbkcolor(COLOR(0,0,0));
                      outtextxy(150,300,"Opcion invalida. Intente otra vez");//texto de error al no pulsar una opcion
                      delay(100);////duracion al cambio de color del mensaje
                      }
                    break;
		}


            HMODULE Lib = LoadLibrary("winmm.dll");
    //fn_PlaySound =  (PlaySoundA_ptr)GetProcAddress(Lib, "PlaySoundA");
    //fn_PlaySound("wwe theme songs-cm punk.wav", NULL, SND_FILENAME |SND_LOOP| SND_ASYNC);



}//fin funcion

void boton(int x,int y,int x2,int y2,int c1,int c2)//funcion para los botones
{
   setcolor(c1);//color de la parte izquierda del boton
   line(x,y,x,y2);
   setcolor(c1);//color de la parte superior del boton
   line(x,y,x2,y);
   setcolor(c2);//color de la parte inferior del boton
   line(x,y2,x2,y2);
   setcolor(c2);//color de la parte derecha del boton
   line(x2,y2,x2,y);
}

void clean()
{
	setfillstyle(1,COLOR(0,0,0));
	bar(20,100,780,643);
}
*/
