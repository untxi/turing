#include "animaciones.h"

animaciones::animaciones()
{
    //ctor
}

animaciones::~animaciones()
{
    //dtor
}
