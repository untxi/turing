#include "circulo.h"

circulo::circulo()
{
    //ctor
}

circulo::~circulo()
{
    //dtor
}
